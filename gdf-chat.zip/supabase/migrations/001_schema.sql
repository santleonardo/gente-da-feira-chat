-- ============================================================
-- GDF Chat — Schema Completo para Supabase
-- Execute este SQL no SQL Editor do Supabase
-- ============================================================

-- ─── Profiles (vinculado ao auth.users do Supabase) ────────
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  avatar TEXT,
  bio TEXT DEFAULT '',
  neighborhood TEXT,
  theme TEXT DEFAULT 'auto',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ─── Rooms (Salas de chat) ─────────────────────────────────
CREATE TABLE rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT DEFAULT '💬',
  type TEXT DEFAULT 'community',
  member_count INT DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── Room Members ──────────────────────────────────────────
CREATE TABLE room_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member',
  joined_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(room_id, user_id)
);

-- ─── Direct Chats (conversas 1-a-1) ───────────────────────
CREATE TABLE direct_chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  initiator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(initiator_id, receiver_id)
);

-- ─── Messages (salas + DMs) ───────────────────────────────
CREATE TYPE message_target AS ENUM ('room', 'dm');

CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type message_target DEFAULT 'room',
  room_id UUID REFERENCES rooms(id) ON DELETE CASCADE,
  dm_id UUID REFERENCES direct_chats(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL DEFAULT '',
  is_deleted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── Posts ─────────────────────────────────────────────────
CREATE TABLE posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  image_url TEXT,
  neighborhood TEXT,
  likes_count INT DEFAULT 0,
  is_deleted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── Reactions (likes nos posts) ───────────────────────────
CREATE TABLE reactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'like',
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- ─── Indexes ──────────────────────────────────────────────
CREATE INDEX idx_messages_room ON messages(room_id, created_at DESC);
CREATE INDEX idx_messages_dm ON messages(dm_id, created_at DESC);
CREATE INDEX idx_posts_author ON posts(author_id, created_at DESC);
CREATE INDEX idx_posts_created ON posts(created_at DESC);
CREATE INDEX idx_room_members_user ON room_members(user_id);
CREATE INDEX idx_reactions_post ON reactions(post_id);
CREATE INDEX idx_direct_chats_participants ON direct_chats(initiator_id, receiver_id);

-- ─── Triggers ─────────────────────────────────────────────

-- Auto-increment member_count
CREATE OR REPLACE FUNCTION update_room_member_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE rooms SET member_count = member_count + 1 WHERE id = NEW.room_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE rooms SET member_count = GREATEST(member_count - 1, 0) WHERE id = OLD.room_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_room_member_count
AFTER INSERT OR DELETE ON room_members
FOR EACH ROW EXECUTE FUNCTION update_room_member_count();

-- Auto-increment likes_count
CREATE OR REPLACE FUNCTION update_post_likes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.type = 'like' THEN
    UPDATE posts SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' AND OLD.type = 'like' THEN
    UPDATE posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_post_likes
AFTER INSERT OR DELETE ON reactions
FOR EACH ROW EXECUTE FUNCTION update_post_likes();

-- Auto-update last_message_at in direct_chats
CREATE OR REPLACE FUNCTION update_dm_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE direct_chats SET updated_at = now(), last_message_at = now() WHERE id = NEW.dm_id;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_dm_timestamp
AFTER INSERT ON messages
FOR EACH ROW EXECUTE FUNCTION update_dm_timestamp();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, username, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substr(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- RLS (Row Level Security)
-- ============================================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE direct_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE reactions ENABLE ROW LEVEL SECURITY;

-- Profiles
CREATE POLICY "profiles_read_all" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Rooms
CREATE POLICY "rooms_read_active" ON rooms FOR SELECT USING (is_active = true);
CREATE POLICY "rooms_insert_auth" ON rooms FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Room members
CREATE POLICY "room_members_read_all" ON room_members FOR SELECT USING (true);
CREATE POLICY "room_members_insert_self" ON room_members FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "room_members_delete_self" ON room_members FOR DELETE USING (auth.uid() = user_id);

-- Direct chats
CREATE POLICY "direct_chats_read_participants" ON direct_chats FOR SELECT USING (
  auth.uid() = initiator_id OR auth.uid() = receiver_id
);
CREATE POLICY "direct_chats_insert_auth" ON direct_chats FOR INSERT WITH CHECK (auth.uid() = initiator_id);
CREATE POLICY "direct_chats_delete_participants" ON direct_chats FOR DELETE USING (
  auth.uid() = initiator_id OR auth.uid() = receiver_id
);

-- Messages
CREATE POLICY "messages_read_members" ON messages FOR SELECT USING (
  (target_type = 'room' AND EXISTS (SELECT 1 FROM room_members WHERE room_id = messages.room_id AND user_id = auth.uid()))
  OR
  (target_type = 'dm' AND EXISTS (SELECT 1 FROM direct_chats WHERE id = messages.dm_id AND (initiator_id = auth.uid() OR receiver_id = auth.uid())))
);
CREATE POLICY "messages_insert_auth" ON messages FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- Posts
CREATE POLICY "posts_read_all" ON posts FOR SELECT USING (is_deleted = false);
CREATE POLICY "posts_insert_auth" ON posts FOR INSERT WITH CHECK (auth.uid() = author_id);
CREATE POLICY "posts_update_own" ON posts FOR UPDATE USING (auth.uid() = author_id);
CREATE POLICY "posts_delete_own" ON posts FOR DELETE USING (auth.uid() = author_id);

-- Reactions
CREATE POLICY "reactions_read_all" ON reactions FOR SELECT USING (true);
CREATE POLICY "reactions_insert_own" ON reactions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reactions_delete_own" ON reactions FOR DELETE USING (auth.uid() = user_id);

-- ============================================================
-- Realtime
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE posts;

-- ============================================================
-- SEED DATA — Salas Oficiais e Comunidades
-- ============================================================
INSERT INTO rooms (name, slug, description, icon, type) VALUES
  ('Geral FSA', 'geral-fsa', 'Conversas gerais sobre Feira de Santana', '💬', 'official'),
  ('Empregos', 'empregos', 'Vagas e oportunidades de trabalho', '💼', 'official'),
  ('Tomba', 'tomba', 'Tudo sobre o bairro Tomba', '🏘️', 'community'),
  ('Mangabeira', 'mangabeira', 'Moradores de Mangabeira', '🏘️', 'community'),
  ('Campo Limpo', 'campo-limpo', 'Vida no Campo Limpo', '🏘️', 'community'),
  ('Eventos', 'eventos', 'Festas, shows e eventos culturais', '🎉', 'official'),
  ('Notícias', 'noticias', 'Acontecimentos e informações da cidade', '📰', 'official'),
  ('Compra e Venda', 'compra-venda', 'Negociação de itens entre moradores', '🛒', 'community'),
  ('Gastronomia', 'gastronomia', 'Receitas, restaurantes e comidas', '🍽️', 'community'),
  ('Esportes', 'esportes', 'Futebol, vôlei e muito mais', '⚽', 'community'),
  ('Saúde', 'saude', 'Dicas de saúde e bem-estar', '🏥', 'official'),
  ('Cultura', 'cultura', 'Arte, música e cultura local', '🎭', 'community'),
  ('Pets', 'pets', 'Adestração, adoção e cuidados', '🐾', 'community'),
  ('Tecnologia', 'tecnologia', 'Tech e inovação em FSA', '💻', 'community');

-- ============================================================
-- STORAGE BUCKETS — execute no dashboard ou via SQL:
-- ============================================================
-- INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('post-images', 'post-images', true);
--
-- CREATE POLICY "avatars_upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
-- CREATE POLICY "avatars_read" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
-- CREATE POLICY "avatars_delete" ON storage.objects FOR DELETE USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
--
-- CREATE POLICY "posts_upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'post-images' AND auth.uid() IS NOT NULL);
-- CREATE POLICY "posts_read" ON storage.objects FOR SELECT USING (bucket_id = 'post-images');
